document.getElementById("toggle-theme").addEventListener("click", function () {
  document.body.classList.toggle("dark");
});
